/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab_2_solutions;

public class FindMaxWorker implements Runnable{
    
    private int beginAt;
    private int endAt;
    private int[] array;
    private int max;
    
    public FindMaxWorker(int beginAt,int endAt,int[] array){
        this.beginAt = beginAt;
        this.endAt = endAt;
        this.array = array;
    }
    
    public void run(){
        max = array[beginAt];
        for (int i = beginAt; i<endAt; i++){
            if(array[i] > max){
                max = array[i];
            }
        }
    }
    
    public int getMax(){
        return max;
    }
}
