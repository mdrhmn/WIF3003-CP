/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab_2_solutions;

public class FindMaxConcurrent {
    private int[] array;
    private int numOfThreads;
    
    public FindMaxConcurrent(int[] array, int numOfThreads){
        this.array = array;
        this.numOfThreads = numOfThreads;
    }
    
    public int getMax(){
        int size = array.length;
        FindMaxWorker fmw[] = new FindMaxWorker[numOfThreads];
        Thread t[] = new Thread[numOfThreads];
        
        int begin = 0;
        int range = array.length / numOfThreads;
        int next = range;
        for (int i = 0; i<numOfThreads; i++){
            if (i == numOfThreads - 1){
                next = size;
            }
            
            fmw[i] = new FindMaxWorker(begin, next, array);
            t[i] = new Thread(fmw[i]);
            t[i].start();
            
            begin = next;
            next += range;
        }
        
        try {
            for(int i = 0; i< numOfThreads; i++){
                t[i].join();
            }
        } catch (InterruptedException ex){
            ex.printStackTrace();
        }
        
        int max = fmw[0].getMax();
        for (int i = 1; i<numOfThreads; i++){
            if(fmw[i].getMax() > max){
                max = fmw[i].getMax();
            }
        }
        
        return max;
    }
    
    
}
