/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab_2_solutions;

public class Timer {
    private long startTime;
    private long finishTime;
    
    public void start(){
        startTime = System.nanoTime();
    }
    
    public void finish(){
        finishTime = System.nanoTime();
    }
    
    public long timeTaken(){
        return finishTime - startTime;
    }
}
