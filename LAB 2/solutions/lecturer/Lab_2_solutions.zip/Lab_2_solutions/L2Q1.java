
package Lab_2_solutions;

import java.util.Random;

public class L2Q1 {
    public static int size = 1000000;
    public static int range = 50000;
    
    public static void main(String[] args){
        final int[] array = new int[size];
        for(int i = 0; i<size; i++){
            Random rand = new Random();
            array[i] = rand.nextInt(range) +1;
        }
        
        Timer t = new Timer();
        int max;
        t.start();
        FindMaxSequential ms1 = new FindMaxSequential(array);
        max = ms1.getMax();
        t.finish();
//        System.out.println("Max is " + ms1.getMax()); // involve io, will increase time
        System.out.println("Max is " + max);
        
        System.out.println("Single thread: Time taken = " + t.timeTaken() + "ns\n");
        
        t.start();
        FindMaxConcurrent fmc2 = new FindMaxConcurrent(array, 2);
        max = fmc2.getMax();
        t.finish();
        System.out.println("Max is " + max);
        System.out.println("Two threads: Time taken = " + t.timeTaken() + "ns\n");
        
        t.start();
        FindMaxConcurrent fmc4 = new FindMaxConcurrent(array, 4);
        max = fmc4.getMax();
        t.finish();
        System.out.println("Max is " + max);
        System.out.println("Four threads: Time taken = " + t.timeTaken() + "ns\n");
    }
    
}
